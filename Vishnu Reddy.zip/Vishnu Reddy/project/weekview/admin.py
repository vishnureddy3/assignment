from django.contrib import admin
from weekview.models import Article
# Register your models here.


admin.site.register(Article)