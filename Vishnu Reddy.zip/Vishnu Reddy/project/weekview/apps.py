from django.apps import AppConfig


class WeekviewConfig(AppConfig):
    name = 'weekview'
