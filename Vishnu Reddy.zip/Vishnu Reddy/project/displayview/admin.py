from django.contrib import admin
from displayview.models import Article

# Register your models here.
admin.site.register(Article)


