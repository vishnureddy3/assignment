from django.apps import AppConfig


class DisplayviewConfig(AppConfig):
    name = 'displayview'
