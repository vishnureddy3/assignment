Django admin Details:-
Username-vishnu
password-12345678


urls:
deailview-http://127.0.0.1:8000/1/
weekview-http://127.0.0.1:8000/2020/week/25